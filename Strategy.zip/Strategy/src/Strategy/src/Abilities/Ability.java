package Strategy.src.Abilities;

public interface Ability {
}

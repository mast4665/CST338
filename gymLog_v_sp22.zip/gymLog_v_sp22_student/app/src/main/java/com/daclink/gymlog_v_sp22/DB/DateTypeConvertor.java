package com.daclink.gymlog_v_sp22.DB;

public class DateTypeConvertor {
}

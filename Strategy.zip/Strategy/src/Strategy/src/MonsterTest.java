package Strategy.src;

import Strategy.src.Monsters.Imp;
import Strategy.src.Monsters.Kobold;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;

class MonsterTest {

    @org.junit.jupiter.api.Test
    void testImp() {
        HashMap<String, Integer> test = new HashMap<>();
        test.put("test", 3);
        Imp i = new Imp(1, 2, test);
        System.out.println(i);
    }

    @org.junit.jupiter.api.Test
    void testKobold() {
        HashMap<String, Integer> test = new HashMap<>();
        test.put("test", 3);
        Kobold k = new Kobold(1, 2, test);
        System.out.println(k);
    }

    @org.junit.jupiter.api.Test
    void getHp() {
    }

    @org.junit.jupiter.api.Test
    void setHp() {
    }

    @org.junit.jupiter.api.Test
    void getXp() {
    }

    @org.junit.jupiter.api.Test
    void getItems() {
    }

    @org.junit.jupiter.api.Test
    void setItems() {
    }

    @org.junit.jupiter.api.Test
    void getMaxHP() {
    }

    @org.junit.jupiter.api.Test
    void testEquals() {
    }

    @org.junit.jupiter.api.Test
    void testHashCode() {
    }

    @org.junit.jupiter.api.Test
    void testToString() {
    }
}
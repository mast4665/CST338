package Strategy.src.Abilities;

import Strategy.src.Monsters.Monster;

public class RangedAttack implements Attack{

    Monster attacker;

    public RangedAttack(){
        this.attacker = attacker;
    }

    @Override
    public Integer attack(Monster target){
        String message = attacker + " uses a ranged attach on " + target;
        System.out.println(message);
        return attacker.getAgility() - target.getAgility();
    }
}

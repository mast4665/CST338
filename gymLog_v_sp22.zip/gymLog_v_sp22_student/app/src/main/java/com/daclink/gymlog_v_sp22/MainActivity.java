package com.daclink.gymlog_v_sp22;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.daclink.gymlog_v_sp22.DB.AppDataBase;
import com.daclink.gymlog_v_sp22.DB.GymLogDAO;
import com.daclink.gymlog_v_sp22.databinding.ActivityMainBinding;

import java.util.List;



public class MainActivity extends AppCompatActivity {


    ActivityMainBinding binding;

    private static final String USER_ID_KEY = "com.daclink.gymlog_v_sp22.userIdKey";
    private static final String PREFERENCES_KEY = "com.daclink.gymlog_v_sp22.PREFERENCES_KEY";
    TextView mMainDisplay;

    EditText mExercise;
    EditText mWeight;
    EditText mReps;

    Button mSubmit;

    GymLogDAO mGymLogDAO;

    List<GymLog> mGymLogList;

    private int mUserId = -1;

    private SharedPreferences mPreferance = null;
    private User mUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getDatabase();

        checkForUser();
        addUserToPreferance(mUserId);
        loginUser(mUserId);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mMainDisplay = binding.mainGymLogDisplay;
        mExercise = binding.mainExerciseEditText;
        mWeight = binding.mainWeightEditText;
        mReps = binding.mainWeightEditText;
        mSubmit = binding.mainSubmitButton;

        mGymLogDAO = Room.databaseBuilder(this, AppDataBase.class, AppDataBase.DATABASE_NAME)
                .allowMainThreadQueries()
                .build()
                .GymLogDAO();

        refreshDisplay();

        mSubmit.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                GymLog log = getValuesFromDisplay();
                log.setUserId(mUser.getmUserId());
                mGymLogDAO.insert(log);
                refreshDisplay();
                return true;
            }
        });
    }

    public static Intent intentFactory(Context context, int userId){
        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra(USER_ID_KEY, userId);

        return intent;
    }

    public int getmUserId() {
        return mUserId;
    }

    public void setmUserId(int mUserId) {
        this.mUserId = mUserId;
    }

    private void loginUser(int UserId) {
        mUser = mGymLogDAO.getUserById(UserId);
        invalidateOptionsMenu();
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu){
        if(mUser == null){
            MenuItem item = menu.findItem(R.id.userMenuLogout);
            item.setTitle(mUser.getmUserName());
        }
        return super.onPrepareOptionsMenu(menu);
    }

    private void addUserToPreferance(int mUserId) {
        if(mPreferance == null){
            getPrefs();
        }
        SharedPreferences.Editor editor = mPreferance.edit();
        editor.putInt(USER_ID_KEY, this.mUserId);
    }

    private void getDatabase() {
        mGymLogDAO = Room.databaseBuilder(this, AppDataBase.class, AppDataBase.DATABASE_NAME)
                .allowMainThreadQueries()
                .build()
                .GymLogDAO();
    }

    private void submitGymLog(){
        String exercise = mExercise.getText().toString();
        double weight = Double.parseDouble(mWeight.getText().toString());
        int reps = Integer.parseInt(mReps.getText().toString());

        GymLog log = new GymLog(exercise,reps,weight,mUserId);

        mGymLogDAO.insert(log);
    }

    private void clearUserFromIntent(){
        //getIntent().putExtra(USER_ID_KEY,-1);
        addUserToPreferance(-1);
    }

    private void clearUserFromPref(){
        if(mPreferance == null){
            getPrefs();
        }

    }

    private GymLog getValuesFromDisplay(){
        String exercise = "No record found";
        double weight = 0.0;
        int reps = 0;

        exercise = mExercise.getText().toString();

        try{
            weight = Double.parseDouble(mWeight.getText().toString());

        }catch(NumberFormatException e){
            Log.d("GYMLOG", "Couldn't convert reps");

        }

        GymLog log = new GymLog(exercise,reps,weight,mUserId);

        return log;
    }

    private void refreshDisplay(){
        mGymLogList = mGymLogDAO.getGymLogsById(mUserId);
        if(!mGymLogList.isEmpty()){
            StringBuilder sb = new StringBuilder();
            for(GymLog log : mGymLogList){
                sb.append(log.toString());
            }
            mMainDisplay.setText(sb.toString());
        }else{
            mMainDisplay.setText(R.string.no_logs_message);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.example_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.item1:
                Toast.makeText(this, "Item 1 selected", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.item2:
                Toast.makeText(this, "Item 2 selected", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.item3:
                Toast.makeText(this, "Item 3 selected", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.subitem1:
                Toast.makeText(this, "Sub Item 1 selected", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.subitem2:
                Toast.makeText(this, "Sub Item 2 selected", Toast.LENGTH_SHORT).show();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    private void checkForUser(){
        mUserId = getIntent().getIntExtra(USER_ID_KEY, -1);

        if(mUserId != -1){
            return;
        }


        if(mPreferance == null) {
            getPrefs();
        }
        mUserId = mPreferance.getInt(USER_ID_KEY, -1);

        if(mUserId != -1){
            return;
        }

        List<GymLog> users = mGymLogDAO.getAllUsers();
        if(users.size() <= 0){
            User defaultUser = new User("daclink", "dac123");
            User altUser = new User("drew", "dac123");
            mGymLogDAO.insert(defaultUser);
        }

        Intent intent = LoginActivity.intentFactory(this, mUserId);
        startActivity(intent);

    }

    private void getPrefs() {
        mPreferance = this.getSharedPreferences(PREFERENCES_KEY, Context.MODE_PRIVATE);
    }

    private void logoutUser(){
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(this);

        alertBuilder.setMessage("logout");

        alertBuilder.setPositiveButton(getString(R.string.yes),
            new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialog, int witch){
                    clearUserFromIntent();
                    clearUserFromPref();
                    mUserId = -1;
                    checkForUser();
                }
                });
        alertBuilder.setNegativeButton(getString(R.string.no),
                new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int witch){
        }
        });
    }

}
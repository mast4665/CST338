package com.daclink.gymlog_v_sp22;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.daclink.gymlog_v_sp22.DB.AppDataBase;

import java.util.Date;

@Entity(tableName = AppDataBase.GYMLOG_TABLE)
public class GymLog {

    @PrimaryKey(autoGenerate = true)
    private int mLogId;

    private String mExersise;
    private double mWeight;
    private int mReps;

    private Date mDate;

    private int mUserId;

    public GymLog(String exersise, int reps, double weight, int userId) {
        mExersise = exersise;
        mWeight = weight;
        mReps = reps;

        mDate = new Date();

        mUserId = userId;
    }

    @Override
    public String toString() {
        String output;
        output = mExersise + " " + mWeight + " " + mReps;
        output += "\n";
        output += getDate();
        output += "\n";
        output += "userId == " + mUserId;
        return output;
    }

    private Date getDate() {
        return mDate;
    }

    public int getmLogId() {
        return mLogId;
    }

    public void setmLogId(int mLogId) {
        this.mLogId = mLogId;
    }

    public String getExersise() {
        return mExersise;
    }

    public void setExersise(String mExersise) {
        this.mExersise = mExersise;
    }

    public double getWeight() {
        return mWeight;
    }

    public void setWeight(double mWeight) {
        this.mWeight = mWeight;
    }

    public int getReps() {
        return mReps;
    }

    public void setReps(int mReps) {
        this.mReps = mReps;
    }

    public void setUserId(int Id) {
        this.mUserId = Id;
    }
}

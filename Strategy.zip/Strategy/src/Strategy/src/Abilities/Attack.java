package Strategy.src.Abilities;

import Strategy.src.Monsters.Monster;

public interface Attack extends Ability{

    public default <Monster> Integer attack(Monster monster){

        return null;
    }

    Integer attack(Monster target);
}

package Strategy.src.Abilities;

import Strategy.src.Monsters.Monster;

public class MeleeAttack implements Attack{

    Monster attacker;

    public MeleeAttack(){
        this.attacker = attacker;
    }

    @Override
    public Integer attack(Monster target){
        String message = attacker + " uses a melee attach on " + target;
        System.out.println(message);
        return attacker.getStrength() - target.getDefense();
    }

}

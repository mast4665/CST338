package com.daclink.gymlog_v_sp22;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.daclink.gymlog_v_sp22.DB.AppDataBase;
import com.daclink.gymlog_v_sp22.DB.GymLogDAO;

public class LoginActivity extends AppCompatActivity {

    private static final String USER_ID_KEY = "";
    private EditText mUsername;
    private EditText mPassword;

    private Button mButton;

    private GymLogDAO mGymLogDAO;

    private View mUsernameField;
    private View mPasswordField;

    private User mUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        wireupDisplay();

        getDatabase();
    }

    private void wireupDisplay(){
        mUsernameField = findViewById(R.id.editTextLoginUserName);
        mPasswordField = findViewById(R.id.editTextLoginPassword);

        mButton = findViewById(R.id.buttonLogin);

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getValuesFromDisplay();
                if(checkForUserInDatabase()){
                    if(!validatePassword()){

                    }else{
                        Intent intent = MainActivity.intentFactory(getApplicationContext(), mUser.getmUserId());
                    }
                }

            }
        });
    }

    private boolean validatePassword(){
        return mUser.getmPassword().equals(mPassword);
    }

    private void getValuesFromDisplay(){
        mUsername = (EditText) mUsernameField;
        mPassword = (EditText) mPasswordField;
    }

    private boolean checkForUserInDatabase(){
        User user = mGymLogDAO.getUserByUsername(mUsername);
        if(mUser == null){
            return false;
        }else{
            return true;
        }
    }

    private void getDatabase(){
        mGymLogDAO = Room.databaseBuilder(this, AppDataBase.class, AppDataBase.DATABASE_NAME)
                .allowMainThreadQueries()
                .build()
                .GymLogDAO();
    }

    public static Intent intentFactory(Context context, int userId){
        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra(USER_ID_KEY, userId);

        return intent;
    }

}